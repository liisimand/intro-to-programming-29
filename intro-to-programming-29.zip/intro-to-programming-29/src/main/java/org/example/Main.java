package org.example;

public class Main {
    // main is method
    // java is case sensitive language
    // main is not the same as Main or mAin
    public static void main(String[] args) {
        // some useful shortcut
        // line duplication
        // mac: cmd + d
        // windows: ctrl + d
        System.out.println("Hello world!");
        System.out.println("Hello world!");
        System.out.println("Hello world!");
        System.out.println("I really don't like Java!");
        System.out.println("I really like Java!");
        //System.out.println("I'm Liisi");
        //System.out.println("I'm Liisi");


    }
}