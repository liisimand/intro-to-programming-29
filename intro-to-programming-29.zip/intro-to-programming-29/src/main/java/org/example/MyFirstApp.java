package org.example;

// use Code - Refactor to reformat source code
public class MyFirstApp {

    // psym
    public static void main(String[] args) {
        // use control + space to show context help
        System.out.println('5');
        System.out.println("5 5 5");
    }
}
